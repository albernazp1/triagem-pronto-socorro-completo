package com.triagempronto.service;

import com.triagempronto.model.Medico;
import com.triagempronto.repository.MedicoRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class MedicoService {
    private final MedicoRepository repo;
    public MedicoService(MedicoRepository repo) { this.repo = repo; }

    public Medico salvar(Medico m) { return repo.save(m); }

    public Medico atualizarPlantao(Long id, boolean emPlantao) {
        return repo.findById(id).map(m -> {
            m.setEmPlantao(emPlantao);
            return repo.save(m);
        }).orElse(null);
    }

    public List<Medico> emPlantao() { return repo.findByEmPlantaoTrue(); }
}
