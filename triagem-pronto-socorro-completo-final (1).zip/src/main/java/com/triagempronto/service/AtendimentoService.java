package com.triagempronto.service;

import com.triagempronto.enums.Gravidade;
import com.triagempronto.enums.Prioridade;
import com.triagempronto.model.Medico;
import com.triagempronto.model.Paciente;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;

@Service
public class AtendimentoService {
    private final TriagemService triagemService;
    private final MedicoService medicoService;

    public AtendimentoService(TriagemService t, MedicoService m) {
        this.triagemService = t;
        this.medicoService = m;
    }

    public Paciente proximoPaciente() {
        List<Medico> medicos = medicoService.emPlantao();
        if (medicos.isEmpty()) return null;

        return triagemService.listarTodos().stream()
            .sorted(Comparator
                .comparing(Paciente::getPrioridade, Comparator.comparingInt(this::ordemPrioridade))
                .thenComparing(Paciente::getGravidade, Comparator.comparingInt(this::ordemGravidade))
                .thenComparing(Paciente::getDataHoraTriagem))
            .findFirst().orElse(null);
    }

    private int ordemPrioridade(Prioridade p) {
        return switch (p) {
            case VERMELHA -> 1;
            case AMARELA -> 2;
            case VERDE -> 3;
        };
    }

    private int ordemGravidade(Gravidade g) {
        return switch (g) {
            case GRAVE -> 1;
            case MODERADA -> 2;
            case LEVE -> 3;
        };
    }
}
