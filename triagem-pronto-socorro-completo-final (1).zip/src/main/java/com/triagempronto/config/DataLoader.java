package com.triagempronto.config;

import com.triagempronto.enums.Gravidade;
import com.triagempronto.enums.Prioridade;
import com.triagempronto.model.Medico;
import com.triagempronto.model.Paciente;
import com.triagempronto.service.MedicoService;
import com.triagempronto.service.TriagemService;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

@Component
public class DataLoader {

    private final TriagemService triagemService;
    private final MedicoService medicoService;

    public DataLoader(TriagemService t, MedicoService m) {
        this.triagemService = t;
        this.medicoService = m;
    }

    @PostConstruct
    public void init() {
        medicoService.salvar(new Medico(null, "Dra. Ana", "Clínico Geral", "123456", true));
        medicoService.salvar(new Medico(null, "Dr. João", "Ortopedista", "654321", false));

        triagemService.salvar(novoPaciente("Carlos", 35, "Febre e dor", Prioridade.AMARELA, Gravidade.MODERADA));
        triagemService.salvar(novoPaciente("Marina", 22, "Fratura exposta", Prioridade.VERMELHA, Gravidade.GRAVE));
        triagemService.salvar(novoPaciente("Lucas", 50, "Dor de cabeça", Prioridade.VERDE, Gravidade.LEVE));
    }

    private Paciente novoPaciente(String nome, int idade, String sintomas, Prioridade prioridade, Gravidade gravidade) {
        Paciente p = new Paciente();
        p.setNome(nome);
        p.setIdade(idade);
        p.setSintomas(sintomas);
        p.setPrioridade(prioridade);
        p.setGravidade(gravidade);
        return p;
    }
}
