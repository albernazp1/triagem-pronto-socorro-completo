package com.triagempronto.controller;

import com.triagempronto.model.Medico;
import com.triagempronto.service.MedicoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/medicos")
public class MedicoController {

    private final MedicoService service;
    public MedicoController(MedicoService service) { this.service = service; }

    @PostMapping
    public ResponseEntity<Medico> cadastrar(@RequestBody Medico medico) {
        return ResponseEntity.ok(service.salvar(medico));
    }

    @PutMapping("/{id}/plantao")
    public ResponseEntity<Medico> atualizarPlantao(@PathVariable Long id, @RequestParam boolean emPlantao) {
        Medico atualizado = service.atualizarPlantao(id, emPlantao);
        return atualizado != null ? ResponseEntity.ok(atualizado) : ResponseEntity.notFound().build();
    }

    @GetMapping("/plantao")
    public ResponseEntity<List<Medico>> listarPlantao() {
        return ResponseEntity.ok(service.emPlantao());
    }
}
