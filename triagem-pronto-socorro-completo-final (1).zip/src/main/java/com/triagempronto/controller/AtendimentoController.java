package com.triagempronto.controller;

import com.triagempronto.model.Paciente;
import com.triagempronto.service.AtendimentoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/atendimento")
public class AtendimentoController {

    private final AtendimentoService service;
    public AtendimentoController(AtendimentoService service) { this.service = service; }

    @GetMapping("/proximo")
    public ResponseEntity<Paciente> proximo() {
        Paciente p = service.proximoPaciente();
        return p != null ? ResponseEntity.ok(p) : ResponseEntity.noContent().build();
    }
}
