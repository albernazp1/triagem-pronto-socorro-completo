package com.triagempronto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TriagemApplication {
    public static void main(String[] args) {
        SpringApplication.run(TriagemApplication.class, args);
    }
}
