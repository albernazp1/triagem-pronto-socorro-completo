package com.triagempronto.enums;
public enum Gravidade { GRAVE, MODERADA, LEVE }
