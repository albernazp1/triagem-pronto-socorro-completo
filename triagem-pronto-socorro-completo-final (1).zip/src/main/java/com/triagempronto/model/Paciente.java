package com.triagempronto.model;

import com.triagempronto.enums.Gravidade;
import com.triagempronto.enums.Prioridade;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Paciente {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nome, sintomas;
    private int idade;
    private LocalDateTime dataHoraTriagem;

    @Enumerated(EnumType.STRING)
    private Prioridade prioridade;
    @Enumerated(EnumType.STRING)
    private Gravidade gravidade;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getSintomas() { return sintomas; }
    public void setSintomas(String sintomas) { this.sintomas = sintomas; }
    public int getIdade() { return idade; }
    public void setIdade(int idade) { this.idade = idade; }
    public LocalDateTime getDataHoraTriagem() { return dataHoraTriagem; }
    public void setDataHoraTriagem(LocalDateTime d) { this.dataHoraTriagem = d; }
    public Prioridade getPrioridade() { return prioridade; }
    public void setPrioridade(Prioridade prioridade) { this.prioridade = prioridade; }
    public Gravidade getGravidade() { return gravidade; }
    public void setGravidade(Gravidade gravidade) { this.gravidade = gravidade; }
}
