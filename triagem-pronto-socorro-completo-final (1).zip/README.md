# Triagem Pronto Socorro
Projeto completo com Spring Boot para triagem hospitalar.